function generateCaptcha() {
    let num1 = Math.floor(Math.random() * 10);
    let num2 = Math.floor(Math.random() * 10);
    document.getElementById("num1").innerText = num1;
    document.getElementById("num2").innerText = num2;
  }
  
  function validateCaptcha() {
    let num1 = parseInt(document.getElementById("num1").innerText);
    let num2 = parseInt(document.getElementById("num2").innerText);
    let userAnswer = parseInt(document.getElementById("answer").value);
  
    if (userAnswer === (num1 + num2)) {
      document.getElementById("status").innerText = "✅ Access Granted";
      document.getElementById("status").style.color = "green";
    } else {
      document.getElementById("status").innerText = "❌ Incorrect CAPTCHA";
      document.getElementById("status").style.color = "red";
    }
  }
  
  // Simulate bot-like behavior detection
  let lastClick = 0;
  document.addEventListener("click", () => {
    let now = new Date().getTime();
    if (now - lastClick < 100) {
      alert("⚠️ Possible Bot Detected! Too many fast clicks.");
    }
    lastClick = now;
  });
  